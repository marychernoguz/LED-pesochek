#include <stdio.h>
#include "pico/stdlib.h"

#include "hardware/pio.h"
#include "hardware/clocks.h"

#define RGB_16x10_HEIGHT 10
#define RGB_16x10_WIDTH 16

#define N_PIXELS 160
#define RGB565_RED 0xf800
#define RGB565_GREEN 0x07e0
#define RGB565_BLUE 0x001f
#define RGB_1F 0x001F1F1F

#define ws2812_wrap_target 0
#define ws2812_wrap 3

#define ws2812_T1 2
#define ws2812_T2 5
#define ws2812_T3 3

#define IMAGE_SIZE (RGB_16x10_HEIGHT * RGB_16x10_WIDTH)

const int PIN_TX = 6;
static uint16_t image_buffer[IMAGE_SIZE] = { 0 }; // all zeros
// static uint16_t image_buffer[IMAGE_SIZE] = {};  // 60 lights

static const uint16_t ws2812_program_instructions[] = {
    //     .wrap_target
0x6221, //  0: out    x, 1            side 0 [2] 
0x1123, //  1: jmp    !x, 3           side 1 [1] 
0x1400, //  2: jmp    0               side 1 [4] 
0xa442, //  3: nop                    side 0 [4] 
    //     .wrap
};

static const struct pio_program ws2812_program = {
    .instructions = ws2812_program_instructions,
    .length = 4,
    .origin = -1,
};

static pio_sm_config ws2812_program_get_default_config(uint offset)
{
    pio_sm_config c = pio_get_default_sm_config();
    sm_config_set_wrap(&c, offset + ws2812_wrap_target, offset + ws2812_wrap);
    sm_config_set_sideset(&c, 1, false, false);
    return c;
}

static void ws2812_program_init(PIO pio, uint sm, uint offset, uint pin, float freq, bool rgbw)
{
    pio_gpio_init(pio, pin);
    pio_sm_set_consecutive_pindirs(pio, sm, pin, 1, true);
    pio_sm_config c = ws2812_program_get_default_config(offset);
    sm_config_set_sideset_pins(&c, pin);
    sm_config_set_out_shift(&c, false, true, rgbw ? 32 : 24);
    sm_config_set_fifo_join(&c, PIO_FIFO_JOIN_TX);
    int cycles_per_bit = ws2812_T1 + ws2812_T2 + ws2812_T3;
    float div = clock_get_hz(clk_sys) / (freq * cycles_per_bit);
    sm_config_set_clkdiv(&c, div);
    pio_sm_init(pio, sm, offset, &c);
    pio_sm_set_enabled(pio, sm, true);
}

uint32_t Conversion(uint16_t Data, uint32_t RGBpwm)
{
    uint32_t Data1 = 0;
    unsigned char Red = (Data & RGB565_RED) >> 8;
    unsigned char Green = (Data & RGB565_GREEN) >> 3;
    unsigned char Blue = (Data & RGB565_BLUE) <<3;
    Data1 = (Red << 16) + (Green << 8) + Blue;
    return Data1 & RGBpwm;
}

void put_pixel(uint32_t pixel_grb) {
    pio_sm_put_blocking(pio0, 0, pixel_grb << 8u);
}

void show(uint16_t* image, uint32_t RGBpwm) {   
    for (uint8_t i = 0; i < N_PIXELS; i++) {
        put_pixel(Conversion(image[i], RGBpwm));
    }
}

void start (uint16_t color){
    for (int i = 0; i < N_PIXELS; i+= 16) {
        for (int j = 0; j < 6; j++){
            image_buffer[i+j] = color;
        }
    }
}

void move_one (int x, uint16_t color){
    image_buffer[x] = 0;
    image_buffer[x + 10] = color;
    show(image_buffer, RGB_1F);
    sleep_ms(100);
}

void start_inverted (uint16_t color){
    for (int i = N_PIXELS - 1; i > 0; i -= 16) {
        for (int j = 5; j >= 0; j -= 1){
            image_buffer[i-j] = color;
        }
    }
}

void move_one_inverted (int x, uint16_t color){
    image_buffer[N_PIXELS - x] = 0;
    image_buffer[N_PIXELS - 10 - x] = color;
    show(image_buffer, RGB_1F);
    sleep_ms(100);
}

void breathing(uint16_t color_b){
    for (int j = 0; j <= 2; j++){
        for (int i = 0; i < N_PIXELS; i++) {
            image_buffer[i] = color_b; 
        }
        show(image_buffer, RGB_1F);
        sleep_ms(100);
        for (int i = 0; i < N_PIXELS; i++) {
            image_buffer[i] = 0; 
        }
        show(image_buffer, RGB_1F);
        sleep_ms(100);
    }
}

int main()
{
    stdio_init_all();

    PIO pio = pio0;
    int sm = 0;
    uint offset = pio_add_program(pio, &ws2812_program);
    ws2812_program_init(pio, sm, offset, PIN_TX, 800000, false);

    uint16_t color_b = 0x7B1C; //for breathing
    uint16_t color = 0XF006; //for lights
    int t = 0;
    bool flag = true;

      
    while (true){
        if (flag = true){
            breathing (color_b);
          
            start (color);
            for (int j = 0; j < 6; j++){
                for (int i = 0; i < N_PIXELS; i+= 16) {
                    move_one (i+j, color);
                }
            }
        
            breathing (color_b);
        }
        // flag = false;
        if (flag = true){
            breathing (color_b);
            start_inverted (color);

            for (int j = 1; j <= 6; j++){
                for (int i = 0; i < N_PIXELS; i+= 16) {
                    move_one_inverted (i+j, color);
                }
            }
        
            breathing (color_b);
        }
        // flag = true;
        // invert();
    }

    return 0;
}
