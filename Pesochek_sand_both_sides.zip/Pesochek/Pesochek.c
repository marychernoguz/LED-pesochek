#include <stdio.h>
#include "pico/stdlib.h"

#include "hardware/pio.h"
#include "hardware/clocks.h"

#define RGB_16x10_HEIGHT 10
#define RGB_16x10_WIDTH 16

#define N_PIXELS 160
#define RGB565_RED 0xf800
#define RGB565_GREEN 0x07e0
#define RGB565_BLUE 0x001f
#define RGB_1F 0x001F1F1F

#define ws2812_wrap_target 0
#define ws2812_wrap 3

#define ws2812_T1 2
#define ws2812_T2 5
#define ws2812_T3 3

#define IMAGE_SIZE (RGB_16x10_HEIGHT * RGB_16x10_WIDTH)

const int PIN_TX = 6;
static uint16_t image_buffer[IMAGE_SIZE] = { 0 }; // all zeros

static const uint16_t ws2812_program_instructions[] = {
    //     .wrap_target
0x6221, //  0: out    x, 1            side 0 [2] 
0x1123, //  1: jmp    !x, 3           side 1 [1] 
0x1400, //  2: jmp    0               side 1 [4] 
0xa442, //  3: nop                    side 0 [4] 
    //     .wrap
};

static const struct pio_program ws2812_program = {
    .instructions = ws2812_program_instructions,
    .length = 4,
    .origin = -1,
};

static pio_sm_config ws2812_program_get_default_config(uint offset)
{
    pio_sm_config c = pio_get_default_sm_config();
    sm_config_set_wrap(&c, offset + ws2812_wrap_target, offset + ws2812_wrap);
    sm_config_set_sideset(&c, 1, false, false);
    return c;
}

static void ws2812_program_init(PIO pio, uint sm, uint offset, uint pin, float freq, bool rgbw)
{
    pio_gpio_init(pio, pin);
    pio_sm_set_consecutive_pindirs(pio, sm, pin, 1, true);
    pio_sm_config c = ws2812_program_get_default_config(offset);
    sm_config_set_sideset_pins(&c, pin);
    sm_config_set_out_shift(&c, false, true, rgbw ? 32 : 24);
    sm_config_set_fifo_join(&c, PIO_FIFO_JOIN_TX);
    int cycles_per_bit = ws2812_T1 + ws2812_T2 + ws2812_T3;
    float div = clock_get_hz(clk_sys) / (freq * cycles_per_bit);
    sm_config_set_clkdiv(&c, div);
    pio_sm_init(pio, sm, offset, &c);
    pio_sm_set_enabled(pio, sm, true);
}

uint32_t Conversion(uint16_t Data, uint32_t RGBpwm)
{
    uint32_t Data1 = 0;
    unsigned char Red = (Data & RGB565_RED) >> 8;
    unsigned char Green = (Data & RGB565_GREEN) >> 3;
    unsigned char Blue = (Data & RGB565_BLUE) <<3;
    Data1 = (Red << 16) + (Green << 8) + Blue;
    return Data1 & RGBpwm;
}

void put_pixel(uint32_t pixel_grb) {
    pio_sm_put_blocking(pio0, 0, pixel_grb << 8u);
}

void show(uint16_t* image, uint32_t RGBpwm) {   
    for (uint8_t i = 0; i < N_PIXELS; i++) {
        put_pixel(Conversion(image[i], RGBpwm));
    }
}

void breathing(uint16_t color_b){
    for (int j = 0; j <= 2; j++){
        for (int i = 0; i < N_PIXELS; i++) {
            image_buffer[i] = color_b; 
        }
        show(image_buffer, RGB_1F);
        sleep_ms(100);
        for (int i = 0; i < N_PIXELS; i++) {
            image_buffer[i] = 0; 
        }
        show(image_buffer, RGB_1F);
        sleep_ms(100);
    }
}

void start_sand (uint16_t color){
    for (int i = 0; i < N_PIXELS; i++) {
        image_buffer[i] = 0;
    }
    for (int i = 0; i < N_PIXELS; i+= 16) {
        for (int j = 0; j < 4; j++){
            image_buffer[i+j] = color;
        }
    }
    for (int i = 20; i < N_PIXELS-20; i+= 16) {
        image_buffer[i] = color;
    }
    for (int i = 37; i < N_PIXELS-37; i+= 16) {
        image_buffer[i] = color;
    }
    for (int i = 54; i < N_PIXELS-54; i+= 16) {
        image_buffer[i] = color;
    }
    image_buffer[71] = color;
    image_buffer[87] = color;
    show(image_buffer, RGB_1F);
}

void start_sand_inv (uint16_t color){
    for (int j = 0; j < 4; j++) {
        for (int i = N_PIXELS - 1; i >= 0; i-= 16){
            image_buffer[i-j] = color;
        }
    }
    for (int i = N_PIXELS-20 - 1; i >= 20; i-= 16) {
        image_buffer[i] = color;
    }
    for (int i = N_PIXELS-37 - 1; i >= 37; i-= 16) {
        image_buffer[i] = color;
    }
    for (int i = N_PIXELS-54 - 1; i >= 54; i-= 16) {
        image_buffer[i] = color;
    }
    
    image_buffer[72] = color;
    image_buffer[88] = color;
    show(image_buffer, RGB_1F);
}

void swap(int x, int y, uint16_t color_1, uint16_t color_2, int time){
    image_buffer[x] = color_1;
    image_buffer[y] = color_2;
    show(image_buffer, RGB_1F);
    sleep_ms(time);
}

void sand_move (uint16_t color_1, uint16_t color_2, int time){
    swap(64, 79, color_1, color_2, time);
    swap(80, 95, color_1, color_2, time);
    swap(48, 63, color_1, color_2, time);
    swap(96, 111, color_1, color_2, time);
    swap(65, 78, color_1, color_2, time);
    swap(81, 94, color_1, color_2, time);
    swap(49, 62, color_1, color_2, time);
    swap(97, 110, color_1, color_2, time);
    swap(32, 47, color_1, color_2, time);
    swap(112, 127, color_1, color_2, time);

    swap(16, 31, color_1, color_2, time);
    swap(128, 143, color_1, color_2, time);
    swap(66, 77, color_1, color_2, time);
    swap(82, 93, color_1, color_2, time);
    swap(0, 15, color_1, color_2, time);
    swap(144, 159, color_1, color_2, time);
    swap(113, 126, color_1, color_2, time);
    swap(33, 46, color_1, color_2, time);
    swap(83, 92, color_1, color_2, time);
    swap(67, 76, color_1, color_2, time);

    swap(98, 109, color_1, color_2, time);
    swap(50, 61, color_1, color_2, time);
    swap(99, 125, color_1, color_2, time);
    swap(51, 45, color_1, color_2, time);
    swap(114, 108, color_1, color_2, time);
    swap(34, 60, color_1, color_2, time);
    swap(129, 142, color_1, color_2, time);
    swap(17, 30, color_1, color_2, time);
    swap(84, 158, color_1, color_2, time);
    swap(68, 14, color_1, color_2, time);

    swap(145, 141, color_1, color_2, time);
    swap(1, 29, color_1, color_2, time);
    swap(130, 157, color_1, color_2, time);
    swap(18, 13, color_1, color_2, time);
    swap(115, 124, color_1, color_2, time);
    swap(35, 44, color_1, color_2, time);
    swap(146, 91, color_1, color_2, time);
    swap(2, 75, color_1, color_2, time);
    swap(85, 90, color_1, color_2, time);
    swap(69, 74, color_1, color_2, time);

    swap(147, 140, color_1, color_2, time);
    swap(3, 28, color_1, color_2, time);
    swap(131, 156, color_1, color_2, time);
    swap(19, 12, color_1, color_2, time);
    swap(132, 106, color_1, color_2, time);
    swap(20, 58, color_1, color_2, time);
    swap(100, 107, color_1, color_2, time);
    swap(52, 59, color_1, color_2, time);
    swap(116, 123, color_1, color_2, time);
    swap(36, 43, color_1, color_2, time);
       
    swap(117, 139, color_1, color_2, time);
    swap(37, 27, color_1, color_2, time);
    swap(101, 89, color_1, color_2, time);
    swap(53, 73, color_1, color_2, time);
    swap(102, 88, color_1, color_2, time);
    swap(54, 72, color_1, color_2, time);
    swap(86, 122, color_1, color_2, time);
    swap(70, 42, color_1, color_2, time);
    swap(87, 105, color_1, color_2, time);
    swap(71, 57, color_1, color_2, time);
}

int main()
{
    stdio_init_all();

    PIO pio = pio0;
    int sm = 0;
    uint offset = pio_add_program(pio, &ws2812_program);
    ws2812_program_init(pio, sm, offset, PIN_TX, 800000, false);

    uint16_t color_b = 0x7B1C; // for breathing
    uint16_t color = 0XF006; // for lights
    uint16_t color_s = 0X0C40; // for sand
    uint16_t color_0 = 0;
    
    int t = 50;
    int flag = 0;

    while (true){
        if (flag == 0){
            start_sand(color_s);
            sand_move(color_0, color_s, t);
            sleep_ms(400);
            breathing (color_b);
            flag = 1;
        }
        if (flag == 1){
            start_sand_inv(color_s);
            sand_move(color_s, color_0, t);
            sleep_ms(400);
            breathing (color_b);
            flag = 0;
        }
    }

    return 0;
}
