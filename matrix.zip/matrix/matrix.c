#include <stdio.h>
#include "pico/stdlib.h"
#include "hardware/spi.h"
#include "LedMatrix/LedMatrix.h"
// // #include "rpi-rgb-led-matrix-master"

// // SPI Defines
// // We are going to use SPI 0, and allocate it to the following GPIO pins
// // Pins can be changed, see the GPIO function select table in the datasheet for information on GPIO assignments
// #define SPI_PORT spi0
// #define PIN_MISO 16
// #define PIN_CS   17
// #define PIN_SCK  18
// #define PIN_MOSI 19


// int main()
// {
//     stdio_init_all();

//     // SPI initialisation. This example will use SPI at 1MHz.
//     spi_init(SPI_PORT, 1000*1000);
//     gpio_set_function(PIN_MISO, GPIO_FUNC_SPI);
//     gpio_set_function(PIN_CS,   GPIO_FUNC_SIO);
//     gpio_set_function(PIN_SCK,  GPIO_FUNC_SPI);
//     gpio_set_function(PIN_MOSI, GPIO_FUNC_SPI);
    
//     // Chip select is active-low, so we'll initialise it to a driven-high state
//     gpio_set_dir(PIN_CS, GPIO_OUT);
//     gpio_put(PIN_CS, 1);
//     // For more examples of SPI use see https://github.com/raspberrypi/pico-examples/tree/master/spi

//     while (true) {
//         printf("Hello, world!\n");
//         sleep_ms(1000);
//     }
// }


int main() {
    // // Инициализация с настройками по умолчанию
    // ledmatrix_init(DEFAULT_SPI_INSTANCE, DEFAULT_SPI_BAUDRATE, 
    //               DEFAULT_SPI_SCK_PIN, DEFAULT_SPI_MOSI_PIN, 
    //               DEFAULT_SPI_CS_PIN);

    // Инициализация с настройками по умолчанию
    ledmatrix_init(spi0, 1000000, 2, 3, 5);

    // Пример использования
    // ledmatrix_set_pixel(0, 0, true);
    // ledmatrix_update();
    
    // Тест 1: Включить все светодиоды
    ledmatrix_set_all(true);
    ledmatrix_update();
    sleep_ms(2000);

    // Тест 2: Бегущая точка
    while (1) {
        for (uint8_t x = 0; x < MATRIX_WIDTH; x++) {
            for (uint8_t y = 0; y < MATRIX_HEIGHT; y++) {
                ledmatrix_clear();
                ledmatrix_set_pixel(x, y, true);
                ledmatrix_update();
                sleep_ms(100);
            }
        }
    }

    return 0;
}