#ifndef LED_MATRIX_H
#define LED_MATRIX_H

#include "pico/stdlib.h"
#include "hardware/spi.h"

// Размеры матрицы (измените под вашу матрицу)
#define MATRIX_WIDTH 8
#define MATRIX_HEIGHT 8

// Настройки SPI по умолчанию
#define DEFAULT_SPI_INSTANCE spi0
#define DEFAULT_SPI_BAUDRATE 1000000
#define DEFAULT_SPI_SCK_PIN 2
#define DEFAULT_SPI_MOSI_PIN 3
#define DEFAULT_SPI_CS_PIN 5

// Инициализация LED матрицы
void ledmatrix_init(spi_inst_t *spi, uint baudrate, uint sck_pin, uint mosi_pin, uint cs_pin);

// Очистка матрицы
void ledmatrix_clear();

// Установка состояния одного пикселя
void ledmatrix_set_pixel(uint8_t x, uint8_t y, bool state);

// Установка состояния всей матрицы
void ledmatrix_set_all(bool state);

// Обновление матрицы (отправка данных)
void ledmatrix_update();

// Рисование символа (5x8)
void ledmatrix_draw_char(char c, uint8_t x_offset);

// Рисование строки с прокруткой
void ledmatrix_draw_scrolling_text(const char *text, uint delay_ms);

#endif // LED_MATRIX_H